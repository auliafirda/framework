<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table border="1">
    <tr>
        <th>Merk</th>
        <th>Warna</th>
        <th>harga</th>
    </tr>
    @foreach($cars as $car)
    <tr>
        <td>{{$car->merk}}</td>
        <td>{{$car->warna}}</td>
        <td>{{$car->harga}}</td>
    </tr>
    @endforeach
    </table>

</body>
</html>