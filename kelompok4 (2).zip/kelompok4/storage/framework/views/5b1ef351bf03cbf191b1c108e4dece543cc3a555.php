<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table border="1">
    <tr>
        <th>Merk</th>
        <th>Warna</th>
        <th>harga</th>
    </tr>
    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($car->merk); ?></td>
        <td><?php echo e($car->warna); ?></td>
        <td><?php echo e($car->harga); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</body>
</html><?php /**PATH C:\xampp\htdocs\kelompok4\resources\views/car.blade.php ENDPATH**/ ?>