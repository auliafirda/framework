<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;


class CreateTbmahasiswaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbmahasiswa', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('nim',9);
            $table->string('namalengkap', 100);
            $table->text('alamat');
            $table->integer('idjurusan');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbmahasiswa');
    }
}
